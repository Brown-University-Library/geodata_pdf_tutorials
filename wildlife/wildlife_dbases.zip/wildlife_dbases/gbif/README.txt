https://www.gbif.org/dataset/e4bd9ece-92b4-4f3a-821c-4f5979e52269

Study Details

Study Name	Sea turtle tracking in Bonaire 2003-2011
Contact Person	Mabel Nava (stcb@bonaireturtles.org)
Metadata author	OBIS-SEAMAP (seamap-contact@duke.edu)
Citation	Nava, M. 2013. Sea turtle tracking in Bonaire 2003-2011. Data downloaded from OBIS-SEAMAP (http://seamap.env.duke.edu/dataset/753) on yyyy-mm-dd. https://doi.org/10.15468/gj3sgc accessed via GBIF.org on 2022-12-02.

GBIF registration

Registration date	April 24, 2021
Metadata last modified	April 24, 2021
Publication date	April 24, 2021
Hosted by	OBIS-SEAMAP
Installation	OBIS-SEAMAP IPT
Installation contacts	Ei Fujioka
Endpoints	http://ipt.env.duke.edu/archive.do?r=zd_753 (Darwin Core Archive) http://ipt.env.duke.edu/eml.do?r=zd_753 (EML)
Preferred identifier	DOI10.15468/gj3sgc
Alternative identifiers	http://ipt.env.duke.edu/resource?r=zd_753

Study Statistics

Temporal scope	October 27, 2003 - March 2, 2011
Geographic scope	Bonaire
Taxonomic scope	Scientific names are based on the Integrated Taxonomic Information System (ITIS).
Species Caretta caretta Loggerhead Sea Turtle, Chelonia mydas Green Sea Turtle, Eretmochelys imbricata Hawksbill Sea Turtle

Download Report

Total	4,808
Licence	CC BY-NC 4.0
Year range	2003�2011
With year	100 %
With coordinates	100 %
With taxon match	100 %

Publication date April 24, 2021
Metadata last modified April 24, 2021
