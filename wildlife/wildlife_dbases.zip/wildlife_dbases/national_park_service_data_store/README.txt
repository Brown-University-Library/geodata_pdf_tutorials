https://irma.nps.gov/DataStore/Reference/Profile/2293856

Study Details

Study Name	Kaibab Plateau Bison Herd Seasonal Ranges
Creators	Skye Salganek (National Park Service); Miranda Terwilliger (National Park Service); Kathryn A. Schoenecker (U.S. Geological Survey)
Stewards	Jered Hansen (National Park Service); Santiago Garcia (National Park Service); Miranda Terwilliger (National Park Service)
Publisher	Grand Canyon National Park
Citation	Salganek S and Others. 2022. Kaibab Plateau Bison Herd Seasonal Ranges. Grand Canyon National Park. Kaibab Plateau, AZhttps://doi.org/10.57830/2293856
DOI	10.57830/2293856
Reference - Date Last Updated	09/27/2022
Reference - Date Created	06/29/2022

License Type
Access Level	Public
Copyright Designation	No Restriction - The information is neither copyrighted nor has any other use restrictions related to it being intellectual property. For that reason, this information may be distributed to the NPS and public
Additional Use Constraints	Hunting is illegal in Grand Canyon National Park and these data shall not to be used for these purposes. The National Park Service shall not be held liable for improper or incorrect use of the data described and/or contained herein. These data and related graphics are not legal documents and are not intended to be used as such. The information contained in these data is dynamic and may change over time. The data are not better than the original sources from which they were derived. It is the responsibility of the data user to use the data appropriately and consistent within the limitations of geospatial data in general and these data in particular. The related graphics are intended to aid the data user in acquiring relevant data; it is not appropriate to use the related graphics as data. The National Park Service gives no warranty, expressed or implied, as to the accuracy, reliability, or completeness of these data. It is strongly recommended that these data are directly acquired from an NPS server and not indirectly through other sources which may have changed the data in some way. Although these data have been processed successfully on a computer system at the National Park Service, no warranty expressed or implied is made regarding the utility of the data on another system or for general or scientific purposes, nor shall the act of distribution constitute any such warranty. This disclaimer applies both to individual use of the data and aggregate use with other data. Please acknowledge this data source, where applicable.
Study Reference Location
Location Description	Kaibab Plateau, AZ
Content Begin Date	January 2019
Content End Date	January 2022

Study Statistics
Category		Mammal
Scientific Name	Bison bison
Common Name	American bison, American Bison, bison, plains bison
Family	Bovidae


