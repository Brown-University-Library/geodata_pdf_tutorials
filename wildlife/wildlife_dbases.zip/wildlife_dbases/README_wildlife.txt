Wildlife Tracking and Observation Sample Data
Frank Donnelly, GIS and Data Librarian
Zeke Hertz, GIS and Data Associate
Brown University Library

December 9, 2022

This folder contains sample data for animal observations and tracks, downloaded from several open access repositories that are described in the document "GIS Data Sources for Wildlife Tracking" at https://libguides.brown.edu/gis_data_tutorials/wildlife. The subfolders are named based on the data source, and contain data and a README file with metadata that links back to the original source.

------

DATA FOLDERS:

gbif: Sea turtle tracking in Bonaire 2003-2011, tab-delimited TXT file

motus: BIRDMOVE - Songbird migration 2017 and spring 2018 (Germany), CSV files for animals, species, detections, and stations

movebank: Wildebeest (Eastern white bearded) Tanzania, point and line shapefiles, or CSV file

national_park_service_data_store: Kaibab Plateau Bison Herd Seasonal Ranges, ESRI file geodatabase

noaa_geoportal: Location-only satellite telemetry data for North Pacific Humpback Whales in the Bering Sea, CSV files

zoatrack: Telemetry of the Mouse-tailed Dormouse (Bulgaria), point and line shapefiles

------

FILE FORMATS AND STRUCTURE:

Data from these sources is packaged in several different formats, representing observations or detections and tracks or traces. Multiple animals / individuals may be stored in one file and identified with a unique number or tag, or each animal may be stored in a separate file.

File formats:

CSV: a plain text format where values are separated by commas, with one record per line. Plot coordinates in QGIS (Data Manager - Add Delimited text) or ArcGIS (Add Data - Add XY data) to generate point data. Usually recorded in longitude (X coordinate) and latitude (Y coordinate). Points can be connected to form lines based on a logical sequence number or timestamp using a Point to Line tool in GIS software.

TXT: a plain text format that uses a delimeter other than a comma. Tabs, pipes, and semicolons are common. Treat just like a CSV, and when plotting in GIS specify the appropriate delimeter.

Excel: to plot in GIS, convert to a CSV format first.

Shapefile: these are GIS-ready files that store points (observations or detections) or lines (tracks, traces, or movements). Shapefiles contain multiple pieces that must be kept together in the same folder. Add them directly to QGIS (Data Manager - Vector data) or ArcGIS (Add Data).

ESRI GEODATABASE: a container that contains many spatial and non-spatial tables, appears like a folder in a file system. View and add components in ArcGIS (Add Data button - Browse into database like a folder) or QGIS (Data Manager - Directory - select Type as OpenFile GDB).
