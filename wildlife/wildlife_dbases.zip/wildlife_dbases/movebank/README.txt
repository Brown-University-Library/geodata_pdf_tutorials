https://www.movebank.org/cms/webapp?gwt_fragment=page=studies,path=study1429664821

Study Details
	
Study Name	Wildebeest (Eastern white bearded) Morrison Tarangire-Manyara Tanzania
Contact Person	tam10 (Tom Morrison)
Principal Investigator	tam10 (Tom Morrison)
Citation	Morrison TA, Link W, Newmark W, Foley C, Bolger DT. 2016. Tarangire revisited: population consequences of loss of migratory connectivity in a tropical ungulate. Biological Conservation. 197, 53-60.
Acknowledgements	Tanzania National Parks (TANAPA), Tanzania wildlife Research Institute (TAWIRI), Tanzania Wildlife Authority (TAWA), Tarangire Elephant Project-WCS, Tembo Foundation
Grants used	Switzer Foundation, Tembo Foundation, Tarangire Elephant Project WCS
License Type	
License Terms	Creative Commons Attribution-NonCommercial (CC BY-NC). Also see the Movebank General Terms of Use.
Study Summary	Identify movement corridors between Tarangire National Park, Simanjiro Plains and Lake Natron basin
Study Reference Location	
Longitude	35.970
Latitude	-3.749
Movebank ID	1429664821

Study Statistics
Number of Animals	6
Number of Tags	6
Number of Deployments	6
Time of First Deployed Location	2009-04-17 12:00:00.000
Time of Last Deployed Location	2011-12-22 20:00:00.000
Taxa	not set
Number of Deployed Locations	6360
Number of Records	Deployed (outliers) / Total (outliers)
  GPS	6360 (0) / 6360 (0)

About study details
Processing Status
	
Up-to-date