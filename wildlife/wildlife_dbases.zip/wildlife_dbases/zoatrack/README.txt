https://www.zoatrack.org/projects/1170/analysis

Study Details
	
Study Name	Telemetry of the Mouse-tailed Dormouse (Myomimus roachi)
Contact Person	Hendrik Queckenstedt (h.queckenstedt@me.com)


License Type	
License Terms	Creative Commons Attribution-NonCommercial (CC BY-NC). Strongly encouraged to contact the data custodians to discuss data usage and appropriate accreditation.

Study Reference Location	
Location	Bulgaria
Spatial Reference System	EPSG:4326

Study Statistics
Number of Animals	1
Date of First Observation	2022-09-15
Date of First Observation	2022-10-09
