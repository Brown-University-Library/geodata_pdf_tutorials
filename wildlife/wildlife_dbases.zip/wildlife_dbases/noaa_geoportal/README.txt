https://www.ncei.noaa.gov/metadata/geoportal/rest/metadata/item/gov.noaa.nodc%3A0138946/html

accessions_id: 	0138946 | archive
Title: 	Location-only satellite telemetry data for North Pacific Humpback Whales in the Bering Sea collected by Alaska Fisheries Science Center, National Marine Mammal Laboratory from 2007-08-11 to 2011-10-08 (NCEI Accession 0138946)
Abstract: 	This dataset contains ARGOS location data (latitude and longitude in decimal format) and associated time (date and time) and location quality (as defined by Argos System, www.argos-system.org) information. Data were collected using Wildlife Computers PTT-only SPOT 5 satellite transmitters and PTT identification is also provided with the data. Satellite transmitters were deployed on North Pacific humpback whales (Megaptera novaeangliae) in the eastern Bering Sea.
Date received: 	20151207
Start date: 	20070811
End date: 	20111008
Seanames: 	Bering Sea, North Pacific Ocean
West boundary: 	170.806
East boundary: 	-164.645
North boundary: 	61.936
South boundary: 	52.803
Observation types: 	biological, in situ, marine mammal observation, navigational
Instrument types: 	GPS, satellite sensor - general
Datatypes: 	BIOLOGICAL DATA, LATITUDE, LONGITUDE, MARINE MAMMALS
Submitter: 	Waite, Janice
Submitting institution: 	US DOC; NOAA; NMFS; Alaska Fisheries Science Center; Marine Mammal Laboratory
Collecting institutions: 	US DOC; NOAA; NMFS; Alaska Fisheries Science Center; Marine Mammal Laboratory
Contributing projects: 	
Platforms: 	
Number of observations: 	
Supplementary information: 	Submission Package ID: UDRC0M
Availability date: 	
Metadata version: 	2
Keydate: 	2015-12-08 15:55:03+00
Editdate: 	2015-12-17 19:40:53+00